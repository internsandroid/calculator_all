package com.example.dell.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    EditText editTxt;
    EditText editTxt1;
    TextView txtView;
    Button add, sub, mul, div;
    float res;
    String c;
    int[] num = new int[10];
    int flag = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTxt = (EditText) findViewById(R.id.editText);
        editTxt1 = (EditText) findViewById(R.id.editText1);
        txtView = (TextView) findViewById(R.id.textView);
        add = (Button) findViewById(R.id.add);
        sub = (Button) findViewById(R.id.sub);
        mul = (Button) findViewById(R.id.mul);
        div = (Button) findViewById(R.id.div);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num = getData();
                if (flag == 0) {
                    c = Integer.toString(num[0] + num[1]);
                    txtView.setText(c);
                } else {
                    txtView.setText("");
                }
            }
        });
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num = getData();
                if (flag == 0) {

                    c = Integer.toString(num[0] - num[1]);
                    txtView.setText(c);
                } else {
                    txtView.setText("");
                }
            }
        });
        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num = getData();
                if (flag == 0) {
                    c = Integer.toString(num[0] * num[1]);
                    txtView.setText(c);
                } else {
                    txtView.setText("");
                }
            }
        });
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num = getData();
                if (num[1] == 0 && flag == 0) {
                    Toast.makeText(MainActivity.this, "Division by zero error", Toast.LENGTH_LONG).show();
                }
                if (flag == 1) {
                    txtView.setText("");
                } else {
                    res = (float) num[0] / (float) num[1];
                    c = Float.toString(res);
                    txtView.setText(c);
                }
            }
        });
    }

    public int[] getData() {
        String number1 = editTxt.getText().toString();
        String number2 = editTxt1.getText().toString();
        int[] num = new int[2];
        try {
            num[0] = Integer.parseInt(number1);
            num[1] = Integer.parseInt(number2);
            flag = 0;
        } catch (NumberFormatException e) {
            Toast.makeText(MainActivity.this, "Enter valid input", Toast.LENGTH_LONG).show();
            flag = 1;
        }
        return num;
    }
}


