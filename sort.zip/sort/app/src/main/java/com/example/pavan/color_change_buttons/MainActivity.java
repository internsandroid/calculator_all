package com.example.pavan.color_change_buttons;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Spannable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView Result;
    EditText Input;
    Button ASButton;

    int i,j,temp,num[];
    String result1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ASButton = (Button) findViewById(R.id.b1);
        Input = (EditText) findViewById(R.id.et1);
        Result = (TextView) findViewById(R.id.t1);

        ASButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BubbleSort();
            }
        });
    }

    public void BubbleSort() {

        Spannable spn = Input.getText();
        num=new int[spn.length()];
        int count=0;
        for (int i = 0; i < spn.length(); i++){
            if((spn.charAt(i)+"").matches(".*\\d.*")) {
                num[i] = Integer.parseInt("" + spn.charAt(i));
                count++;
            }
        }
        int temp=0;
        for (i = 0; i < num.length-1; i++) {
            for (j = 0; j < num.length-1; j++) {
                if (num[j] > num[j+1]) {
                    temp = num[j];
                    num[j] = num[j+1];
                    num[j] = temp;
                }
            }
        }

         result1 = "";
        for (int i = 0; i < num.length; i++){
            result1 += num[i] + " ";
        }
        Result.setText(result1);

    }
}