package com.example.admin.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
Button add,sub,mul,div;
TextView res;
EditText num1,num2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        add=(Button)findViewById(R.id.btn1);
        sub=(Button)findViewById(R.id.btn2);
        mul=(Button)findViewById(R.id.btn3);
        div=(Button)findViewById(R.id.btn4);
        num1=(EditText) findViewById(R.id.edit1);
        num2=(EditText) findViewById(R.id.edit2);
        res=(TextView) findViewById(R.id.text);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer answer=get_nd_display1();
                res.setText(Integer.toString(answer));
            }
        });
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer answer=get_nd_display2();
                res.setText(Integer.toString(answer));
            }
        });
        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer answer=get_nd_display3();
                res.setText(Integer.toString(answer));
            }
        });
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer answer=get_nd_display4();
                res.setText(Integer.toString(answer));
            }
        });

    }
    public Integer get_nd_display1()
    {
        String one=num1.getText().toString();
        String two=num2.getText().toString();
        int a=Integer.parseInt(one);
        int b=Integer.parseInt(two);
        int c=a+b;
        return c;
    }
    public Integer get_nd_display2()
    {
        String one=num1.getText().toString();
        String two=num2.getText().toString();
        int a=Integer.parseInt(one);
        int b=Integer.parseInt(two);
        int c=a-b;
        return c;
    }
    public Integer get_nd_display3()
    {
        String one=num1.getText().toString();
        String two=num2.getText().toString();
        int a=Integer.parseInt(one);
        int b=Integer.parseInt(two);
        int c=a*b;
        return c;
    }
    public Integer get_nd_display4()
    {
        String one=num1.getText().toString();
        String two=num2.getText().toString();
        int a=Integer.parseInt(one);
        int b=Integer.parseInt(two);
        int c=0;
        try{
             c=a/b;

        }
        catch(Exception e)
        {
            Toast.makeText(MainActivity.this,"cannot divide by 0",Toast.LENGTH_LONG).show();
        }
        return c;
    }
}
