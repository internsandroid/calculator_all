package com.example.hp.internship_task1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
Button button,button2,button3,button4;
EditText edit,edit2;
TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button=(Button)findViewById(R.id.button);
        button2=(Button)findViewById(R.id.button2);
        button3=(Button)findViewById(R.id.button3);
        button4=(Button)findViewById(R.id.button4);
        edit=(EditText)findViewById(R.id.edit);
        edit2=(EditText)findViewById(R.id.edit2);
        text=(TextView)findViewById(R.id.text);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double number1 = Integer.parseInt(edit.getText().toString());
                double number2 = Integer.parseInt(edit2.getText().toString());
                double res = number1 + number2;
                text.setText("Answer:" + res);
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double number1 = Integer.parseInt(edit.getText().toString());
                double number2 = Integer.parseInt(edit2.getText().toString());
                double res = number1 - number2;
                text.setText("Answer:" + res);
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double number1 = Integer.parseInt(edit.getText().toString());
                double number2 = Integer.parseInt(edit2.getText().toString());
                double res = number1 *number2;
                text.setText("Answer:" + res);
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double number1 = Integer.parseInt(edit.getText().toString());
                double number2 = Integer.parseInt(edit2.getText().toString());
                double res = number1 / number2;
                text.setText("Answer:" + res);
            }
        });
    }
}

