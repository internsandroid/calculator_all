package com.example.ananya.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button b1,b2,b3,b4;
    EditText ed1,ed2;
    TextView res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=(Button)findViewById(R.id.button);
        b2=(Button)findViewById(R.id.button2);
        b3=(Button)findViewById(R.id.button3);
        b4=(Button)findViewById(R.id.button4);
        res=(TextView)findViewById(R.id.textView);
        ed1=(EditText) findViewById(R.id.editText);
        ed2=(EditText) findViewById(R.id.editText2);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer answer=get_nd_display();
                res.setText(Integer.toString(answer));
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer answer=get_nd_display2();
                res.setText(Integer.toString(answer));
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer answer=get_nd_display3();
                res.setText(Integer.toString(answer));
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String one=ed1.getText().toString();
                String two=ed2.getText().toString();
                float a=Float.parseFloat(one);
                float b=Float.parseFloat(two);
                 try{
                    float c=a/b;
                    res.setText(Float.toString(c));
                }
                catch(Exception e){
                    Toast.makeText(MainActivity.this, "Cannot divide by zero", Toast.LENGTH_SHORT).show();
                }

            }

        });
    }
    public Integer get_nd_display()
    {
        String one=ed1.getText().toString();
        String two=ed2.getText().toString();
        int a=Integer.parseInt(one);
        int b=Integer.parseInt(two);
        int c=a+b;
        return  c;

    }
    public Integer get_nd_display2()
    {
        String one=ed1.getText().toString();
        String two=ed2.getText().toString();
        int a=Integer.parseInt(one);
        int b=Integer.parseInt(two);
        int c=a-b;
        return  c;

    }
    public Integer get_nd_display3()
    {
        String one=ed1.getText().toString();
        String two=ed2.getText().toString();
        int a=Integer.parseInt(one);
        int b=Integer.parseInt(two);
        int c=a*b;
        return  c;

    }


}
